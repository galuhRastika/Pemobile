package com.example.flutter_pemmob

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
